package com.twister.DataBases;

public class DBStatic {

	protected static final String HOST     = "localhost:3306";
	protected static final String DB_NAME  = "firstDataBase";
	protected static final String USERNAME = "java";
	protected static final String PASSWORD = "Tapez_yanis_";
	
	protected static final String MONGO_DB = "yanis_yacine";
	protected static final String MONGO_HOST= "mongodb://localhost:27017";
	
	
	public static boolean MYSQL_POOLING = true;
}
